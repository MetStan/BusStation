﻿//namespace BusStation.ViewModels.Users
//{
//    using System.Collections.Generic;

//    public class LoginViewModel
//    {
//        public string Username { get; init; }

//        public ICollection<ProductViewModel> Products { get; init; }
//    }
//}
