﻿namespace BusStation.ViewModels.Users
{
    public class LoginFormViewModel
    {
        public string Id { get; init; }
        public string Username { get; init; }
        public string Password { get; init; }
    }
}
