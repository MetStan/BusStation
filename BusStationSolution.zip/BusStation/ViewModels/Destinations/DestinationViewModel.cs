﻿namespace BusStation.ViewModels.Destinations
{
    using BusStation.Data.Models;
    using System.Collections;

    public class DestinationViewModel
    {
        public int DestinationId { get; set; }

        public string ImageUrl { get; set; }

        public string Date { get; set; }

        public string Time { get; set; }

        public int Tickets{ get; set; }
    }
}
