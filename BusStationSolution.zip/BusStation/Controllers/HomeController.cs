﻿namespace BusStation.Controllers
{
    using MyWebServer.Http;
    using MyWebServer.Controllers;
    using BusStation.Contracts;

    public class HomeController : Controller
    {
        private readonly IDestination service;

        public HttpResponse Index()
        {
          
            if (User.IsAuthenticated)
            {
                return View("Destination/All");
            }

            return this.View();

        }
    }
}
