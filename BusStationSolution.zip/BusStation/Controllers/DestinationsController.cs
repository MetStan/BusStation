﻿namespace BusStation.Controllers
{
    using BusStation.Contracts;
    using BusStation.ViewModels.Destinations;
    using MyWebServer.Controllers;
    using MyWebServer.Http;
    using System.Collections.Generic;
    using System.Linq;

    public class DestinationsController : Controller
    {
        private readonly IDestination service;

        public DestinationsController(IDestination destinationService)
        {
            service = destinationService;
        }

        [Authorize]
        public HttpResponse Add()
        {
            return View();
        }

        [Authorize]
        public HttpResponse Add(DestinationFormViewModel model)
        {
            List<string> errors = service.CreateDestination(model).ToList();

            if (errors.Any() == false)
            {
                return Redirect("/Destinations/All");
            }

            return View(model);
        }

        public HttpResponse All()
        {
            var destinations = service.GetAllDestinations();

            return View(destinations);
        }
    }
}
