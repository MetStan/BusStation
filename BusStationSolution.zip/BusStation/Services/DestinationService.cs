﻿namespace BusStation.Services
{
    using BusStation.Contracts;
    using BusStation.Data;
    using BusStation.Data.Common;
    using BusStation.Data.Models;
    using BusStation.ViewModels.Destinations;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;

    public class DestinationService : Repository, IDestination
    {
        private readonly IDestination service;
        private readonly IUserService users;
        private readonly IValidatorService validator;

        public DestinationService(BusStationDbContext data,
            IDestination destination,
            IUserService userService,
            IValidatorService validatorService)
            : base(data)
        {
            service = destination;
            users = userService;
            validator = validatorService;
        }

        public ICollection<string> CreateDestination(DestinationFormViewModel model)
        {
            List<string> errors = validator.ValidateModel(model).ToList();

            if (errors.Any())
            {
                return errors;
            }

            DateTime validDate;
            var IsValiddateTime = DateTime.TryParse(model.Date, out validDate);
            var date = string.Empty;
            var time = string.Empty;

            if (IsValiddateTime || validDate >= DateTime.Now)
            {
                var result = validDate.ToString();
                string[] elements = result.Split(' ');
                date = elements[0];
                time = elements[1];
            }
            else
            {
                return errors;
            }

            var newDestination = new Destination
            {
                DestinationName = model.DestinationName,
                Origin = model.Origin,
                ImageUrl = model.ImageUrl,
                Date = date,
                Time = time,
            };

            db.Add(newDestination);
            db.SaveChanges();

            return errors;

        }

        public ICollection<DestinationViewModel> GetAllDestinations()
        {
            var DestinationQuery = All<Destination>();

            var trips = DestinationQuery

                .Select(t => new DestinationViewModel
                {
                    DestinationId = t.Id,
                    ImageUrl = t.ImageUrl,
                    Date =

                    DepartureTime = t.DepartureTime.ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture),
                    Tickets = t.Tickets.Count(),
                })
                .ToList();

            return trips;
        }
    }
}
